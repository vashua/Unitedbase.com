from django.shortcuts import render, redirect, get_object_or_404
from .models import Quiz, Question, Choice, StudentAnswer, Result
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login
from django.http import HttpResponseForbidden
import random



@login_required
def quiz_history(request):
    if request.user.is_staff:
        return redirect('dashboard')
    results = Result.objects.filter(student=request.user).select_related('quiz').order_by('-submitted_at')
    return render(request, 'quiz/history.html', {'results': results})


@login_required
def edit_question(request, question_id):
    question = get_object_or_404(Question, id=question_id)
    if not request.user.is_staff or question.quiz.created_by != request.user:
        return HttpResponseForbidden()

    if request.method == 'POST':
        question.text = request.POST['text']
        question.save()
        return redirect('dashboard')

    return render(request, 'quiz/edit_question.html', {'question': question})


@login_required
def delete_question(request, question_id):
    question = get_object_or_404(Question, id=question_id)
    if not request.user.is_staff or question.quiz.created_by != request.user:
        return HttpResponseForbidden()

    if request.method == 'POST':
        question.delete()
        return redirect('dashboard')

    return render(request, 'quiz/confirm_delete.html', {'question': question})


def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)  # Log the user in immediately
            return redirect('dashboard')
    else:
        form = UserCreationForm()
    return render(request, 'registration/register.html', {'form': form})


def home(request):
    return render(request, 'quiz/home.html')

@login_required
def dashboard(request):
    if request.user.is_staff:
        quizzes = Quiz.objects.filter(created_by=request.user)
        return render(request, 'quiz/teacher_dashboard.html', {'quizzes': quizzes})
    else:
        quizzes = Quiz.objects.all()
        return render(request, 'quiz/student_dashboard.html', {'quizzes': quizzes})

@login_required
def take_quiz(request, quiz_id):
    quiz = get_object_or_404(Quiz, id=quiz_id)
    questions = list(Question.objects.filter(quiz=quiz))
    random.shuffle(questions)
    for question in questions:
        choices = list(question.choice_set.all())
        random.shuffle(choices)
        question.randomized_choices = choices
    if request.method == 'POST':
        score = 0
        for question in questions:
            selected_choice_id = request.POST.get(str(question.id))
            if selected_choice_id:
                choice = Choice.objects.get(id=selected_choice_id)
                StudentAnswer.objects.create(
                    student=request.user,
                    question=question,
                    choice=choice
                )
                if choice.is_correct:
                    score += 1
        Result.objects.create(student=request.user, quiz=quiz, score=score)
        return redirect('view_result', quiz_id=quiz.id)

    return render(request, 'quiz/take_quiz.html', {'quiz': quiz, 'questions': questions})
    

@login_required
def view_result(request, quiz_id):
    result = get_object_or_404(Result, student=request.user, quiz_id=quiz_id)
    return render(request, 'quiz/result.html', {'result': result})

@login_required
def create_quiz(request):
    if not request.user.is_staff:
        return redirect('dashboard')

    if request.method == 'POST':
        title = request.POST['title']
        description = request.POST['description']
        quiz = Quiz.objects.create(title=title, description=description, created_by=request.user)
        return redirect('dashboard')
    
    return render(request, 'quiz/create_quiz.html')

@login_required
def add_question(request, quiz_id):
    if not request.user.is_staff:
        return redirect('dashboard')
    
    quiz = get_object_or_404(Quiz, id=quiz_id, created_by=request.user)

    if request.method == 'POST':
        question_text = request.POST['question']
        question = Question.objects.create(quiz=quiz, text=question_text)

        for i in range(1, 5):
            choice_text = request.POST.get(f'choice{i}')
            is_correct = request.POST.get('correct') == f'choice{i}'
            if choice_text:
                Choice.objects.create(question=question, text=choice_text, is_correct=is_correct)
        
        return redirect('add_question', quiz_id=quiz.id)

    return render(request, 'quiz/add_question.html', {'quiz': quiz})
